package com.example.helpap;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class welcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
    }
}